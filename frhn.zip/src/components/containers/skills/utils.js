export const skillsData = [
  {
    label: "FRONTEND",
    data: [
      {
        skillName: "HTML",
        percentage: "95",
      },
      {
        skillName: "CSS",
        percentage: "90",
      },
      {
        skillName: "Sass",
        percentage: "85",
      },
      {
        skillName: "Bootstrap",
        percentage: "90",
      },
    ],
  },
  {
    label: "FRONTEND",
    data: [
      {
        skillName: "TAILWIND CSS",
        percentage: "85",
      },
      {
        skillName: "REACT-BOOTSTRAP",
        percentage: "85",
      },
      {
        skillName: "JAVASCRIPT",
        percentage: "85",
      },
      {
        skillName: "REACT JS",
        percentage: "85",
      },
    ],
  },
];
