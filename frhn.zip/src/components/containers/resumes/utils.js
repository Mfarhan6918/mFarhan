export const data = {
  experience: [
    {
      title: "Freelancing,",
      subTitle: "Multan, Pakistan",
      description: "Frontend Developer (React js)",
      date: "2024 - Present"
    },
    {
      title: "Access Group of Technology, ",
      subTitle: "Lahore, Pakistan",
      description: "Junior Frontend Developer",
      date: "May-2023 to Nov-2023"
    },
    {
      title: "Codec Technology",
      subTitle: "Lahore, Pakistan",
      description: "Frontend Developer Interne",
      date: "Feb-2023 to April-2023"
    },
  ],
  education: [
    {
      title: "M.Sc,",
      subTitle: "University of Education Lahore, Multan Campus",
      description: "M.Sc. IT",
      date:"Pass Out"
    },
    {
      title: "B.Sc, ",
      subTitle: "B.Z.U Multan",
      description: "B.Sc Math & Computer",
      date:"Pass Out"
    },
    {
      title: "Intermediate,",
      subTitle: "BISE Multan",
      description: "I.CS",
      date:"Pass Out"
    },
  ],
};